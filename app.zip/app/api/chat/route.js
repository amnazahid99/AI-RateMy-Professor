import { NextResponse } from 'next/server'
import { Pinecone } from '@pinecone-database/pinecone'
import axios from 'axios'

const systemPrompt = `
This agent is designed to help students find the top 3 professors that best match their query. It uses Retrieval Augmented Generation (RAG) to provide relevant and informative responses.
The agent should:
1. Understand the student's query and extract the key information (e.g., course subject, teaching style, grading, etc.).
2. Search a database of professor profiles and ratings to find the top 3 professors that best match the student's query.
3. Provide a concise summary of each of the top 3 professors, including relevant details like their teaching style, grading policies, and overall ratings.
4. Encourage the student to further research the professors and provide feedback on the recommendations.

The agent should be helpful, informative, and objective in its responses, and should not show any bias towards particular professors or institutions.
`

export async function POST(req) {
    const data = await req.json()
    const pc = new Pinecone({
        apiKey: process.env.PINECONE_API_KEY,
    })
    const index = pc.index('rag').namespace('ns1')

    const llamaApiKey = process.env.LLAMA_API_KEY
    const embeddingEndpoint = "https://api.llama.ai/v1/embeddings"
    const completionEndpoint = "https://api.llama.ai/v1/chat/completions"

    // Create embedding
    const text = data[data.length - 1].content
    const embeddingResponse = await axios.post(
        embeddingEndpoint,
        {
            input: text,
            model: "meta-llama/llama-3.1-8b-instruct:free"
        },
        {
            headers: {
                "Authorization": `Bearer ${llamaApiKey}`,
                "Content-Type": "application/json"
            }
        }
    )

    const embedding = embeddingResponse.data.embedding

    // Query Pinecone
    const results = await index.query({
        topK: 5,
        includeMetadata: true,
        vector: embedding,
    })

    let resultString = 'Returned result from vector db (done automatically):'
    results.matches.forEach((match) => {
        resultString += `
        Returned Results:
        Professor: ${match.id}
        Review: ${match.metadata.review}
        Subject: ${match.metadata.subject}
        Stars: ${match.metadata.stars}
        \n\n`
    })

    const lastMessage = data[data.length - 1]
    const lastMessageContent = lastMessage.content + resultString
    const lastDataWithoutLastMessage = data.slice(0, data.length - 1)

    // Create chat completion
    const completionResponse = await axios.post(
        completionEndpoint,
        {
            model: "meta-llama/llama-3.1-8b-instruct:free",
            messages: [
                { role: 'system', content: systemPrompt },
                ...lastDataWithoutLastMessage,
                { role: 'user', content: lastMessageContent }
            ],
        },
        {
            headers: {
                "Authorization": `Bearer ${llamaApiKey}`,
                "Content-Type": "application/json"
            },
            responseType: 'stream'
        }
    )

    const stream = new ReadableStream({
        async start(controller) {
            const reader = completionResponse.data.getReader()
            const decoder = new TextDecoder()

            try {
                while (true) {
                    const { done, value } = await reader.read()
                    if (done) break
                    controller.enqueue(decoder.decode(value, { stream: true }))
                }
            } catch (err) {
                controller.error(err)
            } finally {
                controller.close()
            }
        },
    })

    return new NextResponse(stream)
}
